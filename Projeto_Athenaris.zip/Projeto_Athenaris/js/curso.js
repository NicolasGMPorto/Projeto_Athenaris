function inicializarCurso(curso, progressoInicial = {}) {
    const checkboxes = document.querySelectorAll('.check-progresso');
    const barra = document.getElementById('progresso-preenchido');

    function atualizarBarra() {
        const total = checkboxes.length;
        const concluidos = Array.from(checkboxes).filter(c => c.checked).length;
        const percent = Math.round((concluidos / total) * 100);
        if (barra) barra.style.width = percent + '%';
    }

    checkboxes.forEach((check, idx) => {
        check.addEventListener('change', () => {
            const topico = idx + 1;
            const concluido = check.checked ? 1 : 0;
            // enviar como form-urlencoded
            fetch('atualizar_progresso.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: `curso=${encodeURIComponent(curso)}&topico=${topico}&concluido=${concluido}`
            })
            .then(r => r.json())
            .then(data => {
                if (!data.success && !data.sucesso) {
                    alert('Erro ao salvar progresso');
                    check.checked = !check.checked;
                } else {
                    atualizarBarra();
                }
            })
            .catch(err => {
                console.error(err);
                alert('Erro de conexão ao salvar progresso');
                check.checked = !check.checked;
            });
        });
    });

    // inicializar barra com o progresso vindo do servidor (se houver)
    atualizarBarra();
}
