// Troca de abas
document.querySelectorAll('.aba').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.aba').forEach(b => b.classList.remove('ativa'));
        document.querySelectorAll('.conteudo-aba').forEach(c => c.classList.remove('ativo'));
        btn.classList.add('ativa');
        document.getElementById(`aba-${btn.dataset.aba}`).classList.add('ativo');
    });
});

// Util - formatador BRL
const fmt = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

/* ---- Juros Compostos com gráfico ---- */
const formJuros = document.getElementById('formJuros');
let grafico = null;

formJuros.addEventListener('submit', e => {
    e.preventDefault();

    // Ler inputs
    const P = parseFloat(document.getElementById('valorInicial').value) || 0;
    const PMT = parseFloat(document.getElementById('valorMensal').value) || 0;
    const i = (parseFloat(document.getElementById('taxaJuros').value) || 0) / 100;
    const n = parseInt(document.getElementById('tempoMeses').value) || 0;
    if (n <= 0) return alert('Informe um tempo válido em meses.');

    // Simular mês a mês
    let balance = P;
    const timeline = [{ mes: 0, invested: P, interest: 0, total: P }];
    for (let m = 1; m <= n; m++) {
        balance = balance * (1 + i);
        balance += PMT;
        const invested = P + PMT * m;
        const interest = balance - invested;
        timeline.push({ mes: m, invested, interest, total: balance });
    }

    // Agrupar em 10 pontos
    const segments = Math.min(10, n);
    const step = Math.ceil(n / segments);
    const pontos = [];
    for (let k = 1; k <= segments; k++) {
        const m = Math.min(k * step, n);
        pontos.push(timeline[m]);
    }

    // Dados para o gráfico
    const labels = pontos.map(p => (p.mes >= 12 && p.mes % 12 === 0)
        ? `${p.mes / 12}a (${p.mes}m)`
        : `${p.mes}m`
    );

    const investedData = pontos.map(p => Number(p.invested.toFixed(2)));
    const interestData = pontos.map(p => Number(p.interest.toFixed(2)));
    const totalData = pontos.map(p => Number(p.total.toFixed(2)));

    // Atualizar resumo
    const ultimo = timeline[n];
    document.getElementById('montanteFinal').textContent = fmt.format(ultimo.total);
    document.getElementById('jurosGanhos').textContent = fmt.format(ultimo.interest);
    document.getElementById('investidoTotal').textContent = fmt.format(ultimo.invested);

    // Definir máximo do gráfico
    const maxTotal = Math.max(...totalData);
    const suggestedMax = Math.ceil(maxTotal * 1.05);

    // Criar gráfico corrigido
    const ctx = document.getElementById('graficoJuros').getContext('2d');
    if (grafico) grafico.destroy();

    grafico = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Investido',
                    data: investedData,
                    fill: true,
                    backgroundColor: 'rgba(30,58,95,0.12)',
                    borderColor: 'rgba(30,58,95,0.95)',
                    pointRadius: 3,
                    tension: 0.35
                },
                {
                    label: 'Juros',
                    data: interestData,
                    fill: true,
                    backgroundColor: 'rgba(46,172,113,0.16)',
                    borderColor: 'rgba(46,172,113,0.95)',
                    pointRadius: 3,
                    tension: 0.35
                },
                {
                    label: 'Montante',
                    data: totalData,
                    fill: false,
                    borderColor: 'rgba(241,196,15,1)',
                    backgroundColor: 'rgba(241,196,15,0.3)',
                    borderWidth: 3,
                    pointRadius: 0,
                    tension: 0.25,
                    order: 0
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 1000, easing: 'easeOutQuart' },
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: true, position: 'top' },
                tooltip: {
                    callbacks: {
                        title: (items) => items[0].label,
                        label: (context) => {
                            const label = context.dataset.label || '';
                            return `${label}: ${fmt.format(Number(context.raw))}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: '#2C3E50' }
                },
                y: {
                    stacked: false,
                    beginAtZero: true,
                    max: suggestedMax,
                    ticks: {
                        callback: function(value) { return fmt.format(value); },
                        color: '#2C3E50'
                    },
                    grid: { color: 'rgba(200,200,200,0.08)' }
                }
            }
        }
    });

    // Popular tabela detalhada
    const tbody = document.getElementById('tabelaCorpo');
    tbody.innerHTML = '';
    pontos.forEach((p, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${idx + 1}/${pontos.length}</td>
            <td>${p.mes}m</td>
            <td>${fmt.format(p.invested)}</td>
            <td>${fmt.format(p.interest)}</td>
            <td>${fmt.format(p.total)}</td>
        `;
        tbody.appendChild(tr);
    });
});

// --- Formulários secundários ---
document.getElementById('formLucro').addEventListener('submit', e => {
    e.preventDefault();
    const custo = parseFloat(document.getElementById('custo').value) || 0;
    const venda = parseFloat(document.getElementById('precoVenda').value) || 0;
    const lucro = venda - custo;
    const margem = venda ? (lucro / venda) * 100 : 0;
    document.getElementById('lucroBruto').textContent = fmt.format(lucro);
    document.getElementById('margemLucro').textContent = `${margem.toFixed(1)}%`;
});

document.getElementById('formMeta').addEventListener('submit', e => {
    e.preventDefault();
    const alvo = parseFloat(document.getElementById('valorAlvo').value) || 0;
    const meses = parseInt(document.getElementById('tempoMeta').value) || 1;
    const porMes = alvo / meses;
    document.getElementById('valorPorMes').textContent = fmt.format(porMes);
});
